Arduino-ESP8266_libs
====================

Library that make easy to using ESP8266 Serial WiFi Module  (Available only TCP now)

RESET_PIN in this library is mean CH_PD pin

(This is beta version now)
