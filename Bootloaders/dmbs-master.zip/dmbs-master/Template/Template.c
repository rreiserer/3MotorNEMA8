/*
             DMBS Build System
      Released into the public domain.

   dean [at] fourwalledcubicle [dot] com
         www.fourwalledcubicle.com
 */

int main(void)
{
	// Application code here.
}
